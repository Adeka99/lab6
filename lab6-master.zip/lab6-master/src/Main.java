public class Main {

    public static void main(String[] args) {
        Array s = new Array();
        s.createArray();
        A abcd = new A();
        abcd.mapping();
        abcd.out(10);
        abcd.outall();
    }
}
